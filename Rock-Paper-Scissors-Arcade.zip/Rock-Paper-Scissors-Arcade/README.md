# 🕹️ RPS Arcade — Hand Gesture Showdown

A browser-based Rock–Paper–Scissors game with an **arcade fighting-game theme**. Play the computer using real hand gestures read live from your webcam via [MediaPipe Hands](https://google.github.io/mediapipe/solutions/hands.html) — no installs, no server, no ML training required.

![mode](https://img.shields.io/badge/mode-1P%20Camera-ff5d3a) ![status](https://img.shields.io/badge/status-ready-17e9d0)

## ✨ Features

- **Live hand-gesture detection** — show ✊ Rock, ✋ Paper, or ✌️ Scissors to your webcam
- **Fighting-game HUD** — health-bar style scoreboard (You vs CPU), win streak tracker, round draws
- **3-2-1 countdown battles** with sound effects (Web Audio API, no audio files needed)
- **Move List** panel that highlights your gesture live as it's recognized
- **Round Log** — a running history of every throw and result
- **Auto mode** — keep battling back-to-back without clicking Throw each round
- Mirror toggle, camera on/off, mute — fully responsive down to mobile

## 🎮 How to play

1. Open `index.html` in a browser (or visit the GitHub Pages link if enabled)
2. Allow camera access when prompted
3. Hold up Rock, Paper, or Scissors in frame
4. Hit **▶ THROW** — a 3-2-1 countdown locks in your move against the CPU

## 🗂️ Project structure

```
├── index.html    # markup / structure
├── style.css     # arcade theme (colors, layout, animation)
├── app.js        # game logic + MediaPipe hand tracking (unchanged core logic)
└── start_server.bat
```

## 🛠️ Tech

- Vanilla HTML / CSS / JavaScript — no build step, no dependencies to install
- [MediaPipe Hands](https://google.github.io/mediapipe/solutions/hands.html) (via CDN) for real-time hand landmark detection
- Web Audio API for synthesized sound effects
- Fonts: [Teko](https://fonts.google.com/specimen/Teko) & [Rajdhani](https://fonts.google.com/specimen/Rajdhani) for the arcade HUD look, [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk) for body text

## 🚀 Deploying

This is a fully static site — drop it on **GitHub Pages**, Netlify, or Vercel and it just works:

```bash
git init
git add .
git commit -m "RPS Arcade"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

Then enable GitHub Pages on the `main` branch (Settings → Pages) and your game is live.

## 📷 Camera privacy note

All hand-tracking runs **entirely in the browser** — no video frame is ever uploaded or stored anywhere. The camera feed only powers the on-device MediaPipe model.

## 📄 License

Free to use, modify, and share.
